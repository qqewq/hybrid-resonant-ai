# Examples (Safe demos)

This folder contains small, non-deployable example scripts for visualization and concept demonstration. They are intentionally simple and do not implement learning or deployment logic.
