# Ethics & Responsible Release

Key principles:
- **Minimize potential for misuse**: treat high-capability research as dual-use.  
- **Transparency with limits**: publish conceptual results and safety assessments, but avoid operational details that materially enable harmful capability creation.  
- **External Review**: seek audits from independent experts before changing research scope.  
- **Governance**: define decision-makers and emergency stop procedures.

Suggested checklist for any code/doc change:
- Does this change increase system autonomy? If yes -> block until reviewed.
- Does this change provide step-by-step deployment instructions? If yes -> block.
- Have external reviewers reviewed the safety assessment? If no -> require review.
