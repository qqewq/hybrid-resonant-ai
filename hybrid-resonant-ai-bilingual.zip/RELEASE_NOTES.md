# Release Notes

## Версия 0.1 — 2025-08-12
- Инициализация репозитория с базовой структурой.
- Добавлены README, LICENSE, CONTRIBUTING, SECURITY, CODE_OF_CONDUCT.
- Добавлены директории `docs`, `examples`, `src` с заготовками и безопасными демонстрациями.
- Вставлены ссылки на GitHub: https://github.com/qqewq/hybrid-resonant-ai.
- Локализация на русский язык.
