# Release Notes

## Version 0.1 — 2025-08-12
- Initialized repository with basic structure.
- Added README, LICENSE, CONTRIBUTING, SECURITY, CODE_OF_CONDUCT.
- Added directories `docs`, `examples`, `src` with placeholders and safe demos.
- Inserted GitHub link: https://github.com/qqewq/hybrid-resonant-ai.
- Localized for English-speaking users.
