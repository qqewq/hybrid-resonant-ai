---
name: Bug report
about: Report a bug or problem
title: "[BUG]"
labels: bug
---

**Describe the bug**
A clear description of what the bug is.

**Steps to reproduce**
1. ...
2. ...
3. ...

**Expected behavior**
A clear description of what you expected to happen.

**Screenshots or logs**
If applicable, add screenshots or logs.

**Environment**
 - OS: [e.g. Windows 10]
 - Python version: [e.g. 3.10]
