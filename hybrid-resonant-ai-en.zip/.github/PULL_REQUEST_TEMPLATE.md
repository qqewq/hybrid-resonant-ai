---
name: Pull request
about: Propose changes to the project
title: "[PR]"
labels: enhancement
---

**Description of changes**
Describe what changes were made.

**Related issue**
Link to the related issue if any.

**Checks**
- [ ] I have verified that this change does not add dangerous capabilities.
- [ ] I have added or updated documentation.
