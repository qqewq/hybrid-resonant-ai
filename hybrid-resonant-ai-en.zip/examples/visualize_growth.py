"""Safe demo: toy visualization of abstract growth functions.

This script computes two toy functions used in conceptual notes:
Q(t) = Q0 * exp(alpha * t)
I(t) = I0 + (delta * Q0 / alpha) * (exp(alpha * t) - 1)

This is a *toy* demonstration for visualization only. It does NOT implement any learning algorithm, model training, or autonomous system.
"""
import math
import argparse
import os

def Q(t, Q0, alpha):
    return Q0 * math.exp(alpha * t)

def I(t, I0, Q0, alpha, delta):
    if alpha == 0:
        return I0 + delta * Q0 * t
    return I0 + (delta * Q0 / alpha) * (math.exp(alpha * t) - 1)

def main():
    parser = argparse.ArgumentParser(description='Toy visualization of growth functions (safe demo).')
    parser.add_argument('--Q0', type=float, default=100.0)
    parser.add_argument('--I0', type=float, default=10.0)
    parser.add_argument('--alpha', type=float, default=0.44)
    parser.add_argument('--delta', type=float, default=0.17)
    parser.add_argument('--tmax', type=float, default=10.0)
    parser.add_argument('--steps', type=int, default=100)
    args = parser.parse_args()

    ts = [i * args.tmax / args.steps for i in range(args.steps + 1)]
    rows = []
    for t in ts:
        rows.append((t, Q(t, args.Q0, args.alpha), I(t, args.I0, args.Q0, args.alpha, args.delta)))

    # Print a short table to stdout
    print("t,Q(t),I(t)")
    for t, qv, iv in rows[:min(len(rows), 20)]:  # show the first few rows only
        print(f"{t:.3f},{qv:.6f},{iv:.6f}")

    # Save CSV for inspection
    out_dir = os.path.join(os.getcwd(), 'examples_output')
    os.makedirs(out_dir, exist_ok=True)
    csv_path = os.path.join(out_dir, 'growth_demo.csv')
    with open(csv_path, 'w') as f:
        f.write("t,Q,I\n")
        for t, qv, iv in rows:
            f.write(f"{t},{qv},{iv}\n")
    print(f"CSV saved to: {csv_path}")
    print("Note: this is a safe, non-deployable demo. Do not attempt to use this for building autonomous systems.")

if __name__ == '__main__':
    main()
