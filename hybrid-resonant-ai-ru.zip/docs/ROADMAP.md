# Roadmap (Research-focused, Safety-first)

This roadmap describes an incremental, safety-first research plan focused on conceptual validation and governance.

Phases:
1. **Concept Validation (Months 0-3)**  
   - Reproduce toy simulations at small scale (non-deployable).  
   - Independent theoretical review of mathematical claims.

2. **Governance & Ethics (Months 1-6)**  
   - Establish an ethics review board.  
   - Define halting criteria and external audit triggers.

3. **Controlled Experimentation (Months 3-12)**  
   - Only perform small sandboxed experiments with strict access controls and external observers.  
   - Public reporting of outcomes and negative results.

4. **No Autonomous Deployment**  
   - Unless and until comprehensive external approval, do not deploy any system with substantial autonomy or self-modification.

Each phase must document metrics, reviewers, and safety signoffs.
