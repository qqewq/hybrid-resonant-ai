# Placeholder package for hybrid-resonant-ai (no implementation)
